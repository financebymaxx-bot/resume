## FOODMYDOOR Restaurant Website

A warm, appetizing multi-page restaurant site for FOODMYDOOR (Kotdwar, delivering since 2018), using the uploaded logo and the full menu transcribed from the three menu screenshots, with food imagery beside each item.

### Pages (TanStack routes)
- `/` — Home: hero with logo, tagline, badges (4.2★ · 148 reviews · Family Restaurant · Delivery since 2018), featured dishes, CTAs (Call, WhatsApp, Directions), highlights, footer.
- `/menu` — Full menu organized by category with prices and small dish images.
- `/about` — Story, hours (until 10:00 PM), dine-in / drive-through / no-contact delivery info.
- `/contact` — Address, phone, WhatsApp, Google Maps embed, hours.

Shared header (logo + nav + Call Now button) and footer across all routes. Floating action buttons (Call, WhatsApp, Maps, Instagram) on every page.

### Menu content (from screenshots)
Categorized sections with price (Half / Full where applicable):

- **Veg Chinese Starter** — Veg Kabab 60/100, Masala Kabab 80/140, Chilli Potato 80/140, Honey Chilli Potato 100/170, Spring Roll 50/100, Chilli Mushroom 130/230, Veg Manchurian 110/200, Paneer Manchurian 170/310, Chilli Paneer 170/310, Crispy Fried Corn 130/230, Extra Gravy 30
- **Non-Veg Chinese Starter** — Chicken Manchurian 170/310, Chilli Chicken (boneless) 170/310, Chilli Fish (boneless) 160/300, Chicken Lollipop 180/350, Honey Lemon Pepper Chicken 190/360, Chicken 65 (boneless) 170/310, Chicken Pakora (boneless) 170/310, Fish Pakora (boneless) 160/300, Extra Gravy 30
- **Tandoori Starters** — Tandoori Soya Chaap 150/290, Malai Soya Chaap 170/340, Tandoori Mushroom 160/310, Paneer Tikka 180/350, Paneer Malai Tikka 190/360, Chicken Tikka 180/350, Chicken Malai Tikka 190/360, Tandoori Chicken 190/360, Ajwain Fish Tikka
- **Pasta** — Veg Arrabiata (Red) 150/170, Veg Alfredo (White) 170/190, Italian Pockets (Pink) 170/190
- **Pizza (Small/Medium)** — Margherita 120/200, Sweet Corn 160/270, Capsicum Onion Tomato 160/270, Garlic Mushroom 150/260, Farm House 170/280, Paneer 160/270, Spinach Corn Paneer 160/270, Paneer Tikka 190/350, Chicken Lovers 190/350, Chicken Tikka 190/350, Extra Cheese Burst 50/70
- **Choti Si Bhookh** — French Fries 90, Mumbai Pav Bhaji 120, Chole Bhature 120, Mix Veg Pakora 150, Paneer Pakora 190
- **Hyderabadi Biryani** — Steam Rice 100, Jeera Rice 130, Veg Biryani 200, Egg Biryani 200, Chicken Biryani 240, Mutton Biryani
- **Indian Special Curries** — Dal Tadka 100/190, Dal Makhani 150/290, Punjabi Pindi Chole 150/290, Punjabi Rajma Masala 150/290, Punjabi Kadi Pakora 130/250, Jeera Aloo 80/150, Aloo Gobhi Masala 150/280, Mix Vegetable 170/350, Matar Mushroom Masala 170/350, Mushroom Do Pyaaza 170/350, Kadai Mushroom 170/350, Kadai Soya Chaap 160/300, Soya Chaap Makhani 180/350, Palak Paneer 170/330, Matar Paneer 180/350, Malai Kofta 180/350, Paneer Do Pyaza 190/370, Kadai Paneer 190/370, Paneer Makhani 190/370, Paneer Lababdar 190/370, Paneer Butter Masala 190/370, Shahi Paneer 190/370, Paneer Bhurji 220

Each item shows name + price. Each category gets one representative small dish image. Half/Full labels shown clearly.

### Visual direction
- Warm appetizing palette: deep red `#D32F2F`, vibrant orange `#FF5722`, warm yellow `#FFC107`, dark `#1A1A1A`, off-white `#FFF8F5`.
- Fonts: Playfair Display (headings) + Poppins (body).
- Uploaded logo prominently in header and hero.
- Subtle hover lifts on menu cards, smooth scroll, no flashy gimmicks.
- Floating Call / WhatsApp / Maps / Instagram buttons.

### Technical notes
- Copy logo to `src/assets/logo.png` and import.
- Generate ~10 small food images (one per category + a hero food shot) into `src/assets/` via imagegen.
- One `menuData.ts` with categorized items; `/` shows featured subset, `/menu` shows all.
- Per-route `head()` meta (title, description, og tags) for SEO.
- Mobile responsive with a working hamburger nav (replacing the original "hide nav on mobile" approach).
- Tokens in `src/styles.css` (`oklch` values for the warm palette); no hardcoded colors in components.
