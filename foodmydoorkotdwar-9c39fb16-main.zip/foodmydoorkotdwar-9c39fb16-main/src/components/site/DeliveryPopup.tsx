import { useState, useEffect } from "react";
import { X, Truck, Clock, Phone, ChevronRight } from "lucide-react";
import { RESTAURANT } from "@/data/menu";
import { Link } from "@tanstack/react-router";

export function DeliveryPopup() {
  const [show, setShow] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const dismissed = sessionStorage.getItem("popup-dismissed");
    if (!dismissed) {
      const t = setTimeout(() => {
        setShow(true);
        requestAnimationFrame(() => setMounted(true));
      }, 1200);
      return () => clearTimeout(t);
    }
  }, []);

  const dismiss = () => {
    setMounted(false);
    setTimeout(() => {
      setShow(false);
      sessionStorage.setItem("popup-dismissed", "1");
    }, 350);
  };

  if (!show) return null;

  return (
    <div
      className={`fixed inset-0 z-[100] flex items-center justify-center px-4 transition-all duration-300 ${
        mounted ? "bg-black/60 backdrop-blur-sm" : "bg-black/0 backdrop-blur-none"
      }`}
      onClick={(e) => {
        if (e.target === e.currentTarget) dismiss();
      }}
      role="dialog"
      aria-modal="true"
    >
      <div
        className={`relative w-full max-w-md rounded-2xl border-2 border-secondary overflow-hidden shadow-warm transition-all duration-300 ${
          mounted ? "opacity-100 translate-y-1 scale-100" : "opacity-0 translate-y-6 scale-95"
        }`}
        style={{ background: "var(--gradient-warm)" }}
      >
        {/* close */}
        <button
          onClick={dismiss}
          className="absolute top-3 right-3 p-1.5 rounded-full bg-white/20 text-white hover:bg-white/30 transition-colors"
          aria-label="Close popup"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="px-6 pt-8 pb-6 text-center text-white">
          <div className="mx-auto mb-4 flex items-center justify-center gap-2 rounded-full bg-white/20 w-fit px-4 py-1.5 text-xs font-semibold uppercase tracking-wider">
            <Truck className="w-4 h-4" /> Fast Delivery
          </div>

          <h2 className="text-2xl md:text-3xl font-bold leading-tight">
            Delivery at your doorstep
          </h2>
          <p className="mt-1 text-lg font-semibold text-white/95">
            within <span className="underline decoration-accent decoration-2 underline-offset-4">30 mins</span>
          </p>

          <div className="mt-5 flex items-center justify-center gap-2 text-sm text-white/90">
            <Clock className="w-4 h-4" />
            <span>Open now · {RESTAURANT.hours}</span>
          </div>

          <p className="mt-3 text-sm text-white/85">
            Order food quickly — hot, fresh & safely packed.
          </p>

          <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
            <a
              href={`tel:${RESTAURANT.phone}`}
              className="inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold text-primary bg-white hover:bg-white/90 transition-colors shadow-lg"
            >
              <Phone className="w-4 h-4" /> Call {RESTAURANT.phoneDisplay}
            </a>
            <Link
              to="/menu"
              onClick={dismiss}
              className="inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold text-white border-2 border-white/70 hover:bg-white/10 transition-colors"
            >
              View Menu <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        {/* bottom bar */}
        <div className="bg-white/10 px-6 py-2.5 text-center text-[11px] text-white/70">
          FOODMYDOOR · {RESTAURANT.address}
        </div>
      </div>
    </div>
  );
}
