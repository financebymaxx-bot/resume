import { Link } from "@tanstack/react-router";
import { MapPin, Phone, Clock, Instagram } from "lucide-react";
import { RESTAURANT } from "@/data/menu";
import logo from "@/assets/logo.png";

export function Footer() {
  return (
    <footer className="bg-dark-bg text-white/80 mt-20">
      <div className="max-w-7xl mx-auto px-6 py-14 grid gap-10 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <img src={logo} alt="FOODMYDOOR" width={48} height={48} className="rounded-full" />
            <div>
              <div className="font-serif font-bold text-accent text-lg">FOODMYDOOR</div>
              <div className="text-xs text-secondary">{RESTAURANT.hindi} · Since 2018</div>
            </div>
          </div>
          <p className="text-sm text-white/60">
            The taste of Kotdwar — North Indian, Chinese, Tandoori, Pizza & Biryani, delivered fresh.
          </p>
        </div>

        <div>
          <h4 className="text-white font-semibold mb-3">Explore</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/" className="hover:text-accent">Home</Link></li>
            <li><Link to="/menu" className="hover:text-accent">Menu</Link></li>
            <li><Link to="/about" className="hover:text-accent">About</Link></li>
            <li><Link to="/contact" className="hover:text-accent">Contact</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-semibold mb-3">Visit</h4>
          <ul className="space-y-2 text-sm">
            <li className="flex items-start gap-2"><MapPin className="w-4 h-4 mt-0.5 text-secondary" /> {RESTAURANT.address}</li>
            <li className="flex items-start gap-2"><Clock className="w-4 h-4 mt-0.5 text-secondary" /> {RESTAURANT.hours}</li>
            <li className="flex items-start gap-2"><Phone className="w-4 h-4 mt-0.5 text-secondary" /> <a href={`tel:${RESTAURANT.phone}`} className="hover:text-accent">{RESTAURANT.phoneDisplay}</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-semibold mb-3">Follow</h4>
          <a href={RESTAURANT.instagram} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm hover:text-accent">
            <Instagram className="w-4 h-4" /> @foodmydoor
          </a>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-white/50">
        © {new Date().getFullYear()} FOODMYDOOR · Kotdwar · Delivering since 2018
      </div>
    </footer>
  );
}