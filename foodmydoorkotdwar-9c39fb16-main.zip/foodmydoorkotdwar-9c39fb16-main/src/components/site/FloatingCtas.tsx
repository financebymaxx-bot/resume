import { Phone, MapPin, Instagram, MessageCircle } from "lucide-react";
import { RESTAURANT } from "@/data/menu";

export function FloatingCtas() {
  const btn = "w-12 h-12 rounded-full flex items-center justify-center text-white shadow-lg hover:scale-110 transition-transform";
  return (
    <div className="fixed right-4 bottom-6 z-40 flex flex-col gap-3">
      <a aria-label="WhatsApp" href={`https://wa.me/${RESTAURANT.whatsapp}`} target="_blank" rel="noreferrer" className={btn} style={{ background: "#25D366" }}>
        <MessageCircle className="w-5 h-5" />
      </a>
      <a aria-label="Call" href={`tel:${RESTAURANT.phone}`} className={btn} style={{ background: "var(--primary)" }}>
        <Phone className="w-5 h-5" />
      </a>
      <a aria-label="Directions" href={RESTAURANT.mapsUrl} target="_blank" rel="noreferrer" className={btn} style={{ background: "#4285F4" }}>
        <MapPin className="w-5 h-5" />
      </a>
      <a aria-label="Instagram" href={RESTAURANT.instagram} target="_blank" rel="noreferrer" className={btn} style={{ background: "linear-gradient(45deg,#f09433,#dc2743,#bc1888)" }}>
        <Instagram className="w-5 h-5" />
      </a>
    </div>
  );
}