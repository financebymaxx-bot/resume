import type { MenuCategory as Cat } from "@/data/menu";

function priceText(item: Cat["items"][number]) {
  if (item.price != null) return `₹${item.price}`;
  if (item.half != null && item.full != null) return `₹${item.half} / ₹${item.full}`;
  return item.note ?? "—";
}

export function MenuCategorySection({ cat }: { cat: Cat }) {
  return (
    <section id={cat.id} className="scroll-mt-24">
      <div className="grid md:grid-cols-[260px_1fr] gap-6 bg-card rounded-2xl overflow-hidden shadow-warm border border-border">
        <div className="relative h-56 md:h-full min-h-[220px]">
          <img
            src={cat.image}
            alt={cat.title}
            loading="lazy"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
          <div className="absolute bottom-3 left-4 right-4">
            <h3 className="font-serif text-2xl text-white drop-shadow">{cat.title}</h3>
            {cat.subtitle && <p className="text-white/80 text-xs">{cat.subtitle}</p>}
          </div>
        </div>
        <div className="p-5 md:p-6">
          <div className="flex justify-between text-xs uppercase tracking-wider text-muted-foreground border-b border-border pb-2 mb-3">
            <span>Item</span>
            <span>{cat.priceLabel}</span>
          </div>
          <ul className="divide-y divide-border">
            {cat.items.map((it) => (
              <li key={it.name} className="flex items-center justify-between gap-4 py-2.5">
                <span className="text-sm md:text-base font-medium text-foreground">{it.name}</span>
                <span className="text-sm md:text-base font-semibold text-primary whitespace-nowrap">
                  {priceText(it)}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}