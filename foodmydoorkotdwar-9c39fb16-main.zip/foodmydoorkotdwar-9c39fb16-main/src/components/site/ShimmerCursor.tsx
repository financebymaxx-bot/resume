import { useEffect } from "react";

export function ShimmerCursor() {
  useEffect(() => {
    let last = 0;
    const onMove = (e: MouseEvent) => {
      const now = performance.now();
      if (now - last < 28) return;
      last = now;
      const dot = document.createElement("span");
      dot.className = "shimmer-dot";
      dot.style.left = e.clientX + "px";
      dot.style.top = e.clientY + "px";
      const jitter = (Math.random() - 0.5) * 6;
      dot.style.transform = `translate(calc(-50% + ${jitter}px), calc(-50% + ${jitter}px)) scale(${0.8 + Math.random() * 0.6})`;
      document.body.appendChild(dot);
      setTimeout(() => dot.remove(), 750);
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, []);
  return null;
}