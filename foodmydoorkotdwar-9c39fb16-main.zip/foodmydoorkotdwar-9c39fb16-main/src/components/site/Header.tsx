import { Link } from "@tanstack/react-router";
import { Phone, Menu as MenuIcon, X } from "lucide-react";
import { useState } from "react";
import logo from "@/assets/logo.png";
import { RESTAURANT } from "@/data/menu";

const links = [
  { to: "/", label: "Home" },
  { to: "/menu", label: "Menu" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed top-0 inset-x-0 z-50 backdrop-blur-md bg-dark-bg/90 border-b-2 border-primary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16">
        <Link to="/" className="flex items-center gap-2" onClick={() => setOpen(false)}>
          <img src={logo} alt="FOODMYDOOR logo" width={44} height={44} className="rounded-full" />
          <div className="leading-tight">
            <div className="font-serif font-bold text-accent text-lg">FOODMYDOOR</div>
            <div className="text-[10px] text-secondary tracking-wide">Delivering since 2018</div>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-7">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              activeOptions={{ exact: l.to === "/" }}
              activeProps={{ className: "text-accent" }}
              className="text-sm font-medium text-white/90 hover:text-accent transition-colors"
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <a
          href={`tel:${RESTAURANT.phone}`}
          className="hidden sm:inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold text-white shadow-warm"
          style={{ background: "var(--gradient-warm)" }}
        >
          <Phone className="w-4 h-4" /> Call Now
        </a>

        <button
          className="md:hidden text-white p-2"
          aria-label="Toggle menu"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
        </button>
      </div>

      {open && (
        <div className="md:hidden border-t border-white/10 bg-dark-bg">
          <div className="px-4 py-4 flex flex-col gap-3">
            {links.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                activeOptions={{ exact: l.to === "/" }}
                activeProps={{ className: "text-accent" }}
                className="text-base text-white/90"
              >
                {l.label}
              </Link>
            ))}
            <a
              href={`tel:${RESTAURANT.phone}`}
              className="inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold text-white w-fit"
              style={{ background: "var(--gradient-warm)" }}
            >
              <Phone className="w-4 h-4" /> Call {RESTAURANT.phoneDisplay}
            </a>
          </div>
        </div>
      )}
    </header>
  );
}