import { createFileRoute } from "@tanstack/react-router";
import { Phone, MapPin, Clock, MessageCircle, Instagram } from "lucide-react";
import { RESTAURANT } from "@/data/menu";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [
      { title: "Contact FOODMYDOOR — Kotdwar | Order & Directions" },
      { name: "description", content: "Call, WhatsApp or visit FOODMYDOOR in Kotdwar. Open daily 11 AM to 10 PM for dine-in, drive-through and delivery." },
      { property: "og:title", content: "Contact FOODMYDOOR" },
      { property: "og:description", content: "Reach FOODMYDOOR Kotdwar by call, WhatsApp or in person." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
});

function ContactPage() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-16">
      <header className="text-center mb-12">
        <p className="text-secondary uppercase tracking-[0.3em] text-xs">Visit Us</p>
        <h1 className="font-serif text-5xl md:text-6xl text-primary mt-2">We're easy to find</h1>
      </header>

      <div className="grid md:grid-cols-2 gap-8 items-start">
        <div className="bg-dark-bg text-white rounded-2xl p-8 border-l-4 border-accent space-y-5">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 mt-1 text-secondary" />
            <div>
              <div className="text-xs uppercase tracking-wider text-white/60">Address</div>
              <div className="text-base">{RESTAURANT.address}</div>
              <a href={RESTAURANT.mapsUrl} target="_blank" rel="noreferrer" className="text-accent text-sm hover:underline">Get directions →</a>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Phone className="w-5 h-5 mt-1 text-secondary" />
            <div>
              <div className="text-xs uppercase tracking-wider text-white/60">Phone</div>
              <a href={`tel:${RESTAURANT.phone}`} className="text-base hover:text-accent">{RESTAURANT.phoneDisplay}</a>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <MessageCircle className="w-5 h-5 mt-1 text-secondary" />
            <div>
              <div className="text-xs uppercase tracking-wider text-white/60">WhatsApp</div>
              <a href={`https://wa.me/${RESTAURANT.whatsapp}`} target="_blank" rel="noreferrer" className="text-base hover:text-accent">Chat with us</a>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Clock className="w-5 h-5 mt-1 text-secondary" />
            <div>
              <div className="text-xs uppercase tracking-wider text-white/60">Hours</div>
              <div className="text-base">Every day · {RESTAURANT.hours}</div>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Instagram className="w-5 h-5 mt-1 text-secondary" />
            <div>
              <div className="text-xs uppercase tracking-wider text-white/60">Follow</div>
              <a href={RESTAURANT.instagram} target="_blank" rel="noreferrer" className="text-base hover:text-accent">@foodmydoor</a>
            </div>
          </div>
        </div>

        <div className="rounded-2xl overflow-hidden border border-border shadow-warm h-[420px]">
          <iframe
            title="FOODMYDOOR location"
            src="https://www.google.com/maps?q=FOODMYDOOR+Kotdwar&output=embed"
            className="w-full h-full"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </div>
  );
}