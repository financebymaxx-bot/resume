import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { FloatingCtas } from "@/components/site/FloatingCtas";
import { ShimmerCursor } from "@/components/site/ShimmerCursor";
import { DeliveryPopup } from "@/components/site/DeliveryPopup";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "FOODMYDOOR — Best Food Restaurant in Kotdwar | Delivering Since 2018" },
      { name: "description", content: "FOODMYDOOR Kotdwar — North Indian, Chinese, Tandoori, Pizza, Pasta & Biryani. Dine-in, drive-through and no-contact delivery until 10 PM." },
      { name: "author", content: "FOODMYDOOR" },
      { property: "og:site_name", content: "FOODMYDOOR" },
      { property: "og:title", content: "FOODMYDOOR — Best Food Restaurant in Kotdwar | Delivering Since 2018" },
      { property: "og:description", content: "FOODMYDOOR Kotdwar — North Indian, Chinese, Tandoori, Pizza, Pasta & Biryani. Dine-in, drive-through and no-contact delivery until 10 PM." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@Lovable" },
      { name: "twitter:title", content: "FOODMYDOOR — Best Food Restaurant in Kotdwar | Delivering Since 2018" },
      { name: "twitter:description", content: "FOODMYDOOR Kotdwar — North Indian, Chinese, Tandoori, Pizza, Pasta & Biryani. Dine-in, drive-through and no-contact delivery until 10 PM." },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/Cwb7vhy5eVexCy3uqrEImmw7i9r1/social-images/social-1779347161112-ChatGPT_Image_May_21,_2026,_12_23_03_PM.webp" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/Cwb7vhy5eVexCy3uqrEImmw7i9r1/social-images/social-1779347161112-ChatGPT_Image_May_21,_2026,_12_23_03_PM.webp" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Russo+One&family=Saira:wght@300;400;500;600;700&display=swap" },
      {
        rel: "stylesheet",
        href: appCss,
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <Header />
      <main className="pt-16 min-h-screen">
        <Outlet />
      </main>
      <Footer />
      <FloatingCtas />
      <ShimmerCursor />
      <DeliveryPopup />
    </QueryClientProvider>
  );
}
