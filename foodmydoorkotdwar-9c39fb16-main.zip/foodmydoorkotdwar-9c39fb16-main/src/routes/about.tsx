import { createFileRoute } from "@tanstack/react-router";
import { Award, Heart, Utensils, Truck } from "lucide-react";
import hero from "@/assets/hero.jpg";
import { RESTAURANT } from "@/data/menu";

export const Route = createFileRoute("/about")({
  component: AboutPage,
  head: () => ({
    meta: [
      { title: "About FOODMYDOOR — Family Restaurant in Kotdwar" },
      { name: "description", content: "Since 2018, FOODMYDOOR has been Kotdwar's go-to family restaurant for North Indian, Chinese and tandoori favorites." },
      { property: "og:title", content: "About FOODMYDOOR" },
      { property: "og:description", content: "Our story — feeding Kotdwar since 2018 with warmth, flavor and consistency." },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
});

function AboutPage() {
  return (
    <div>
      <section className="relative h-[55vh] flex items-center justify-center text-center">
        <img src={hero} alt="FOODMYDOOR kitchen" width={1600} height={1024} className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-dark-bg/75" />
        <div className="relative px-6">
          <p className="text-secondary uppercase tracking-[0.3em] text-xs">Our Story</p>
          <h1 className="font-serif text-5xl md:text-6xl text-accent mt-2">Made with heart, since 2018</h1>
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-6 py-16">
        <p className="text-lg leading-relaxed text-foreground">
          FOODMYDOOR began with one simple idea: bring the warmth of a home-cooked meal
          to every doorstep in Kotdwar. What started as a small kitchen has grown into a
          beloved family restaurant — known for our generous portions, fresh ingredients,
          and a menu that travels from the dhabas of Punjab to the streets of Hyderabad
          and the wood-fired pizzerias of Italy.
        </p>
        <p className="text-lg leading-relaxed text-foreground mt-4">
          Whether you're stopping in for a slow family dinner, grabbing a quick bite at
          the drive-through, or having your favorite biryani delivered no-contact —
          we cook every plate the same way: like it's going to someone we love.
        </p>
      </section>

      <section className="max-w-6xl mx-auto px-6 pb-20 grid md:grid-cols-4 gap-6">
        {[
          { icon: Award, label: "Since 2018", text: "Seven years of serving Kotdwar with consistency." },
          { icon: Heart, label: `${RESTAURANT.rating} ★ Rating`, text: `${RESTAURANT.reviews} happy guests and counting.` },
          { icon: Utensils, label: "100+ Dishes", text: "Indian, Chinese, Tandoori, Pizza, Pasta & Biryani." },
          { icon: Truck, label: "No-Contact Delivery", text: "Hot, sealed and on time, every time." },
        ].map(({ icon: Icon, label, text }) => (
          <div key={label} className="bg-card border border-border rounded-2xl p-6 text-center">
            <div className="w-12 h-12 mx-auto mb-3 rounded-full flex items-center justify-center text-white" style={{ background: "var(--gradient-warm)" }}>
              <Icon className="w-5 h-5" />
            </div>
            <div className="font-serif text-xl">{label}</div>
            <p className="text-sm text-muted-foreground mt-1">{text}</p>
          </div>
        ))}
      </section>
    </div>
  );
}