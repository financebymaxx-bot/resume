import { createFileRoute } from "@tanstack/react-router";
import { menu, RESTAURANT } from "@/data/menu";
import { MenuCategorySection } from "@/components/site/MenuCategory";

export const Route = createFileRoute("/menu")({
  component: MenuPage,
  head: () => ({
    meta: [
      { title: "Menu — FOODMYDOOR Kotdwar" },
      { name: "description", content: "Full FOODMYDOOR menu: Tandoori, Chinese, Pizza, Pasta, Hyderabadi Biryani and Indian special curries with prices." },
      { property: "og:title", content: "FOODMYDOOR Menu" },
      { property: "og:description", content: "Browse our full menu with prices — starters, biryani, pizza, curries and more." },
      { property: "og:url", content: "/menu" },
    ],
    links: [{ rel: "canonical", href: "/menu" }],
  }),
});

function MenuPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
      <header className="text-center mb-12">
        <p className="text-secondary uppercase tracking-[0.3em] text-xs">Our Menu</p>
        <h1 className="font-serif text-4xl md:text-6xl text-primary mt-2">Cooked fresh, served warm</h1>
        <p className="text-muted-foreground mt-3 max-w-xl mx-auto">
          Prices in ₹. All dishes prepared fresh on order. Available for dine-in, drive-through and delivery until 10:00 PM.
        </p>
      </header>

      {/* category nav */}
      <nav className="flex flex-wrap justify-center gap-2 mb-12">
        {menu.map((c) => (
          <a key={c.id} href={`#${c.id}`} className="text-xs sm:text-sm px-3 py-1.5 rounded-full border border-border bg-card hover:bg-accent hover:text-dark-bg transition-colors">
            {c.title}
          </a>
        ))}
      </nav>

      <div className="space-y-10">
        {menu.map((cat) => (
          <MenuCategorySection key={cat.id} cat={cat} />
        ))}
      </div>

      <p className="text-center text-xs text-muted-foreground mt-10">
        Menu subject to availability · Taxes extra · Call {RESTAURANT.phoneDisplay} for assistance
      </p>
    </div>
  );
}