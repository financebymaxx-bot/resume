import { createFileRoute, Link } from "@tanstack/react-router";
import { Star, Utensils, Truck, Clock, ChevronRight } from "lucide-react";
import hero from "@/assets/hero.jpg";
import logo from "@/assets/logo.png";
import { menu, RESTAURANT } from "@/data/menu";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "FOODMYDOOR — Best Food Restaurant in Kotdwar | Since 2018" },
      { name: "description", content: "FOODMYDOOR Kotdwar — Tandoori, biryani, pizza, Chinese and Indian curries. Dine-in, drive-through and no-contact delivery until 10 PM." },
      { property: "og:title", content: "FOODMYDOOR — Delivering Since 2018" },
      { property: "og:description", content: "Best food restaurant in Kotdwar. Order tandoori, biryani, pizza, Chinese and Indian curries." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Restaurant",
        name: "FOODMYDOOR",
        servesCuisine: ["Indian", "Chinese", "Italian"],
        address: { "@type": "PostalAddress", addressLocality: "Kotdwar", addressRegion: "Uttarakhand", addressCountry: "IN" },
        telephone: RESTAURANT.phone,
        priceRange: "₹₹",
        aggregateRating: { "@type": "AggregateRating", ratingValue: RESTAURANT.rating, reviewCount: RESTAURANT.reviews },
      }),
    }],
  }),
});

function Index() {
  const featured = menu.slice(0, 6);
  return (
    <>
      {/* Hero */}
      <section className="relative min-h-[92vh] flex items-center justify-center text-center overflow-hidden">
        <img src={hero} alt="FOODMYDOOR signature dishes" width={1600} height={1024} className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-dark-bg/85 via-dark-bg/70 to-dark-bg/95" />
        <div className="relative px-6 max-w-3xl py-24">
          <img src={logo} alt="FOODMYDOOR" width={140} height={140} className="mx-auto mb-6 rounded-full ring-4 ring-secondary/40 shadow-2xl" />
          <h1 className="font-serif text-5xl md:text-7xl font-bold text-accent leading-tight">
            Taste the warmth of <span className="text-secondary">Kotdwar</span>
          </h1>
          <p className="mt-2 text-secondary text-sm tracking-[0.3em] uppercase">{RESTAURANT.hindi} · Since 2018</p>

          <div className="mt-6 flex flex-wrap justify-center gap-2 text-white">
            <span className="inline-flex items-center gap-1 text-sm bg-white/10 border border-secondary/60 px-3 py-1 rounded-full">
              <Star className="w-3.5 h-3.5 text-accent fill-accent" /> {RESTAURANT.rating} · {RESTAURANT.reviews} reviews
            </span>
            <span className="text-sm bg-white/10 border border-secondary/60 px-3 py-1 rounded-full">Family Restaurant</span>
            <span className="text-sm bg-white/10 border border-secondary/60 px-3 py-1 rounded-full">₹1–200 per person</span>
          </div>

          <p className="mt-6 text-white/90 text-base md:text-lg max-w-xl mx-auto">
            Dine-in, drive-through and no-contact delivery, every day until 10:00 PM.
          </p>

          <div className="mt-8 flex flex-wrap gap-3 justify-center">
            <Link to="/menu" className="inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold text-white shadow-warm" style={{ background: "var(--gradient-warm)" }}>
              View Full Menu <ChevronRight className="w-4 h-4" />
            </Link>
            <a href={`tel:${RESTAURANT.phone}`} className="inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold text-accent border border-accent/60 hover:bg-accent hover:text-dark-bg transition-colors">
              Order on Call
            </a>
          </div>
        </div>
      </section>

      {/* Highlights */}
      <section className="max-w-6xl mx-auto px-6 py-16 grid md:grid-cols-3 gap-6">
        {[
          { icon: Utensils, title: "Dine-In", text: "Cozy family seating with a warm Kotdwar vibe." },
          { icon: Truck, title: "No-Contact Delivery", text: "Hot meals delivered to your door, safely sealed." },
          { icon: Clock, title: "Open Till 10 PM", text: "Late-night cravings? We serve until 10:00 PM daily." },
        ].map(({ icon: Icon, title, text }) => (
          <div key={title} className="bg-card border border-border rounded-2xl p-6 text-center hover:-translate-y-1 transition-transform shadow-sm">
            <div className="w-12 h-12 mx-auto mb-3 rounded-full flex items-center justify-center text-white" style={{ background: "var(--gradient-warm)" }}>
              <Icon className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-xl mb-1">{title}</h3>
            <p className="text-sm text-muted-foreground">{text}</p>
          </div>
        ))}
      </section>

      {/* Featured menu */}
      <section className="max-w-7xl mx-auto px-6 pb-16">
        <div className="text-center mb-10">
          <p className="text-secondary uppercase tracking-[0.3em] text-xs">Menu Highlights</p>
          <h2 className="font-serif text-4xl md:text-5xl text-primary mt-2">A taste of everything</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featured.map((cat) => (
            <Link key={cat.id} to="/menu" hash={cat.id} className="group block bg-card rounded-2xl overflow-hidden border border-border hover:-translate-y-1 transition-transform shadow-sm">
              <div className="relative h-48 overflow-hidden">
                <img src={cat.image} alt={cat.title} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-dark-bg/80 to-transparent" />
                <h3 className="absolute bottom-3 left-4 font-serif text-2xl text-white">{cat.title}</h3>
              </div>
              <div className="p-4 flex items-center justify-between">
                <span className="text-sm text-muted-foreground">{cat.items.length} items</span>
                <span className="text-sm font-semibold text-primary inline-flex items-center gap-1">
                  See menu <ChevronRight className="w-4 h-4" />
                </span>
              </div>
            </Link>
          ))}
        </div>
        <div className="text-center mt-10">
          <Link to="/menu" className="inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold text-white shadow-warm" style={{ background: "var(--gradient-warm)" }}>
            View complete menu <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* CTA strip */}
      <section className="bg-dark-bg text-white py-14">
        <div className="max-w-5xl mx-auto px-6 text-center">
          <h2 className="font-serif text-3xl md:text-4xl text-accent">Hungry? We're a phone call away.</h2>
          <p className="text-white/70 mt-3">Order now for dine-in, pickup or no-contact delivery across Kotdwar.</p>
          <div className="mt-6 flex justify-center gap-3 flex-wrap">
            <a href={`tel:${RESTAURANT.phone}`} className="rounded-full px-6 py-3 text-sm font-semibold text-white" style={{ background: "var(--gradient-warm)" }}>Call {RESTAURANT.phoneDisplay}</a>
            <a href={`https://wa.me/${RESTAURANT.whatsapp}`} target="_blank" rel="noreferrer" className="rounded-full px-6 py-3 text-sm font-semibold text-dark-bg bg-accent">WhatsApp Us</a>
          </div>
        </div>
      </section>
    </>
  );
}
