import vegChinese from "@/assets/veg-chinese.jpg";
import nonvegChinese from "@/assets/nonveg-chinese.jpg";
import tandoori from "@/assets/tandoori.jpg";
import pasta from "@/assets/pasta.jpg";
import pizza from "@/assets/pizza.jpg";
import snacks from "@/assets/snacks.jpg";
import biryani from "@/assets/biryani.jpg";
import curry from "@/assets/curry.jpg";

export type MenuItem = {
  name: string;
  half?: number;
  full?: number;
  price?: number; // for single-price items
  note?: string;
};

export type MenuCategory = {
  id: string;
  title: string;
  subtitle?: string;
  image: string;
  priceLabel: string; // e.g. "Half / Full"
  items: MenuItem[];
};

export const menu: MenuCategory[] = [
  {
    id: "veg-chinese",
    title: "Veg Chinese Starter",
    image: vegChinese,
    priceLabel: "H / F",
    items: [
      { name: "Veg Kabab", half: 60, full: 100 },
      { name: "Masala Kabab", half: 80, full: 140 },
      { name: "Chilli Potato", half: 80, full: 140 },
      { name: "Honey Chilli Potato", half: 100, full: 170 },
      { name: "Spring Roll", half: 50, full: 100 },
      { name: "Chilli Mushroom", half: 130, full: 230 },
      { name: "Veg Manchurian", half: 110, full: 200 },
      { name: "Paneer Manchurian", half: 170, full: 310 },
      { name: "Chilli Paneer", half: 170, full: 310 },
      { name: "Crispy Fried Corn", half: 130, full: 230 },
      { name: "Extra Gravy", price: 30 },
    ],
  },
  {
    id: "nonveg-chinese",
    title: "Non-Veg Chinese Starter",
    image: nonvegChinese,
    priceLabel: "H / F",
    items: [
      { name: "Chicken Manchurian", half: 170, full: 310 },
      { name: "Chilli Chicken (boneless)", half: 170, full: 310 },
      { name: "Chilli Fish (boneless)", half: 160, full: 300 },
      { name: "Chicken Lollipop", half: 180, full: 350 },
      { name: "Honey Lemon Pepper Chicken", half: 190, full: 360 },
      { name: "Chicken 65 (boneless)", half: 170, full: 310 },
      { name: "Chicken Pakora (boneless)", half: 170, full: 310 },
      { name: "Fish Pakora (boneless)", half: 160, full: 300 },
      { name: "Extra Gravy", price: 30 },
    ],
  },
  {
    id: "tandoori",
    title: "Tandoori Starters",
    image: tandoori,
    priceLabel: "H / F",
    items: [
      { name: "Tandoori Soya Chaap", half: 150, full: 290 },
      { name: "Malai Soya Chaap", half: 170, full: 340 },
      { name: "Tandoori Mushroom", half: 160, full: 310 },
      { name: "Paneer Tikka", half: 180, full: 350 },
      { name: "Paneer Malai Tikka", half: 190, full: 360 },
      { name: "Chicken Tikka", half: 180, full: 350 },
      { name: "Chicken Malai Tikka", half: 190, full: 360 },
      { name: "Tandoori Chicken", half: 190, full: 360 },
      { name: "Ajwain Fish Tikka", note: "Seasonal" },
    ],
  },
  {
    id: "pasta",
    title: "Pasta",
    image: pasta,
    priceLabel: "Veg / Non-Veg",
    items: [
      { name: "Veg Arrabiata (Red Sauce)", half: 150, full: 170 },
      { name: "Veg Alfredo (White Sauce)", half: 170, full: 190 },
      { name: "Italian Pockets (Pink Sauce)", half: 170, full: 190 },
    ],
  },
  {
    id: "pizza",
    title: "Pizza",
    image: pizza,
    priceLabel: "Small / Medium",
    items: [
      { name: "Margherita Pizza", half: 120, full: 200 },
      { name: "Sweet Corn Pizza", half: 160, full: 270 },
      { name: "Capsicum Onion Tomato", half: 160, full: 270 },
      { name: "Garlic Mushroom Pizza", half: 150, full: 260 },
      { name: "Farm House Pizza", half: 170, full: 280 },
      { name: "Paneer Pizza", half: 160, full: 270 },
      { name: "Spinach Corn Paneer Pizza", half: 160, full: 270 },
      { name: "Paneer Tikka Pizza", half: 190, full: 350 },
      { name: "Chicken Lovers Pizza", half: 190, full: 350 },
      { name: "Chicken Tikka Pizza", half: 190, full: 350 },
      { name: "Extra Cheese Burst", half: 50, full: 70 },
    ],
  },
  {
    id: "choti-bhookh",
    title: "Choti Si Bhookh",
    image: snacks,
    priceLabel: "Price",
    items: [
      { name: "French Fries", price: 90 },
      { name: "Mumbai Style Pav Bhaji", price: 120 },
      { name: "Chole Bhature", price: 120 },
      { name: "Mix Vegetable Pakora", price: 150 },
      { name: "Paneer Pakora", price: 190 },
    ],
  },
  {
    id: "biryani",
    title: "Hyderabadi Biryani",
    subtitle: "Served with raita",
    image: biryani,
    priceLabel: "Price",
    items: [
      { name: "Steam Rice", price: 100 },
      { name: "Jeera Rice", price: 130 },
      { name: "Veg Biryani (with Raita)", price: 200 },
      { name: "Egg Biryani (with Raita)", price: 200 },
      { name: "Chicken Biryani (with Raita)", price: 240 },
      { name: "Mutton Biryani (with Raita)", note: "Ask for price" },
    ],
  },
  {
    id: "curries",
    title: "Indian Special Curries",
    image: curry,
    priceLabel: "H / F",
    items: [
      { name: "Dal Tadka", half: 100, full: 190 },
      { name: "Dal Makhani", half: 150, full: 290 },
      { name: "Punjabi Pindi Chole", half: 150, full: 290 },
      { name: "Punjabi Rajma Masala", half: 150, full: 290 },
      { name: "Punjabi Kadi Pakora", half: 130, full: 250 },
      { name: "Jeera Aloo", half: 80, full: 150 },
      { name: "Aloo Gobhi Masala", half: 150, full: 280 },
      { name: "Mix Vegetable", half: 170, full: 350 },
      { name: "Matar Mushroom Masala", half: 170, full: 350 },
      { name: "Mushroom Do Pyaaza", half: 170, full: 350 },
      { name: "Kadai Mushroom", half: 170, full: 350 },
      { name: "Kadai Soya Chaap", half: 160, full: 300 },
      { name: "Soya Chaap Makhani", half: 180, full: 350 },
      { name: "Palak Paneer", half: 170, full: 330 },
      { name: "Matar Paneer", half: 180, full: 350 },
      { name: "Malai Kofta", half: 180, full: 350 },
      { name: "Paneer Do Pyaza", half: 190, full: 370 },
      { name: "Kadai Paneer", half: 190, full: 370 },
      { name: "Paneer Makhani", half: 190, full: 370 },
      { name: "Paneer Lababdar", half: 190, full: 370 },
      { name: "Paneer Butter Masala", half: 190, full: 370 },
      { name: "Shahi Paneer", half: 190, full: 370 },
      { name: "Paneer Bhurji", price: 220 },
    ],
  },
];

export const RESTAURANT = {
  name: "FOODMYDOOR",
  tagline: "Delivering since 2018",
  hindi: "फुडमाइडोर",
  phone: "+917055776607",
  phoneDisplay: "+91 70557 76607",
  whatsapp: "917055776607",
  address: "Kotdwar, Uttarakhand",
  mapsUrl: "https://www.google.com/maps/place/FOODMYDOOR+-+Delivering+since+2018",
  instagram: "https://instagram.com/foodmydoor",
  hours: "11:00 AM – 10:00 PM",
  rating: 4.2,
  reviews: 148,
};